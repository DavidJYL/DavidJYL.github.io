#include <bits/stdc++.h>
using namespace std;
int a[27],st[27],stlocat[27],alocat[27];
int mohu=0xf3f3,sum;
string s,ans;
int main() {
    cin>>s;
    for(int i=0;i<s.length();i++){
        st[s[i]-96]++;
        stlocat[s[i]-96]+=i+1;
    }
    freopen("data.txt", "r", stdin);
    string english,chinese;
    for(int i=1;i<=5;i++){
        cin>>english>>chinese;
        if (english==s){
            cout<<chinese<<endl;
            return 0;
        }
        for(int i=0;i<english.length();i++){
            a[english[i]-96]++;
            alocat[english[i]-96]+=i+1;
        }
        for(int i=1;i<=26;i++){
            sum+=abs(a[i]-st[i])^2+abs(alocat[i]-stlocat[i]);
            alocat[i]=a[i]=0;
        }
        if(sum<mohu){
            ans=chinese;
            mohu=sum;
        }
        sum=0;
    }
    cout<<ans<<endl;
    return 0;
}